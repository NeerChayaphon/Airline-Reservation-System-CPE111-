//
//  updateFlight.c
//  FinalProject2
//
//  Created by chayaphon bunyakan on 30/4/2563 BE.
//  Copyright © 2563 chayaphon bunyakan. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "updateFlight.h"
#include "flightNetwork.h"

void editDataInFile(FLIGHT_T *pFlight,int seatInput)
{
    char inputline[128] = "";
    char departure[32] = "";
    char arrival[32] = "";
    char flightID[32] = "";
    char departureHour[32] = "";
    char departureMinute[32] = "";
    char arrivalHour[32] = "";
    char arrivalMinute[32] = "";
    char airport1[32] = "";
    char airport2[32] = "";
    int dayOfMonth = 0;
    int seat = 0;
    FILE *pData = NULL;
    FILE *pTemporaryData = NULL;
    
    
    pData = fopen("flight.txt","r");
    pTemporaryData = fopen("flightTemp.txt","w");
    
    if (pData == NULL)
        {
            printf("Error open file\n");
            exit(0);
        }
    
    while (fgets(inputline, sizeof(inputline), pData) != NULL)
       {
           sscanf(inputline, "%s %s %s %s %s %s %s %s %s %d %d", departure, arrival, flightID, departureHour, departureMinute, arrivalHour, arrivalMinute, airport1, airport2,&dayOfMonth,&seat);
           
           if ((strcmp(departure,pFlight->departure) == 0) && (strcmp(arrival,pFlight->arrival) == 0) && (strcmp(flightID,pFlight->flightID) == 0) && (strcmp(departureHour,pFlight->departureHour) == 0) && (strcmp(departureMinute,pFlight->departureMinute) == 0) && (strcmp(arrivalHour,pFlight->arrivalHour) == 0) && (strcmp(arrivalMinute,pFlight->arrivalMinute) == 0) && (strcmp(airport1,pFlight->airport1) == 0) && (strcmp(airport2,pFlight->airport2) == 0) && (dayOfMonth == pFlight->dayOfMonth) && (seat == pFlight->seat))
           {
               fprintf(pTemporaryData,"%s %s %s %s %s %s %s %s %s %d %d\n", departure, arrival, flightID, departureHour, departureMinute, arrivalHour, arrivalMinute, airport1, airport2,dayOfMonth,seat-seatInput);
           }
           
           else
           {
                fprintf(pTemporaryData,"%s %s %s %s %s %s %s %s %s %d %d\n", departure, arrival, flightID, departureHour, departureMinute, arrivalHour, arrivalMinute, airport1, airport2,dayOfMonth,seat);
           }
       }
    fclose(pTemporaryData);
    fclose(pData);
    
    remove("flight.txt");
    rename("flightTemp.txt","flight.txt");
}

void updateFlight(FLIGHT_T *pFlight, int flightCount,int seat)
{
    if (flightCount == 1)
    {
        editDataInFile(pFlight,seat);
    }
    else if (flightCount == 2)
    {
        editDataInFile(pFlight,seat);
        editDataInFile(pFlight->transit,seat);
    }
    else if (flightCount == 3)
    {
        editDataInFile(pFlight,seat);
        editDataInFile(pFlight->transit,seat);
        editDataInFile(pFlight->transit->transit,seat);
    }
}

