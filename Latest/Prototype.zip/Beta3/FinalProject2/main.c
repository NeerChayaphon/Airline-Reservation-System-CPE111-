/* Created by chayaphon bunyakan (Neer) 62070503412
 Team valid */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "networkBuilder.h"
#include "abstractNetwork.h"
#include "flightNetwork.h"
#include "flightFinder.h"

typedef struct
{
    char departure[32];
    char arrival[32];
    int departureDay;
    int passenger;

} DATA_T;

int main(int argc, const char *argv[])
{
    char input[32];
    DATA_T inputData;
    int pathCheck = 0;
    int choice = 0;
    int locationCheck = 0;
    int dateCheck = 0;
    char bookMore[32];

    printf("\n******** Wellcome to Airline Resevation System ********\n");

    while (1)
    {
        memset(input, 0, sizeof(input));
        memset(inputData.departure, 0, sizeof(inputData.departure));
        memset(inputData.arrival, 0, sizeof(inputData.arrival));
        inputData.departureDay = 0;
        inputData.passenger = 0;
        pathCheck = 0;
        choice = 0;
        readNetworkDefinition("networkInput.txt", 0);

        printf(" \n ** What do you want to do **\n\n");
        printf(" 1) Book flight\n");
        printf(" 2) Exit the program\n\n");

        while ((choice != 1) || (choice != 2))
        {
            printf(" Enter choice : ");
            fgets(input, sizeof(input), stdin);
            sscanf(input, "%d", &choice);

            if (choice == 2)
            {
                printf("Good bye\n");
                exit(1);
            }
            else if (choice == 1)
            {
                break;
            }
            else
            {
                printf(" Enter only (1 and 2)\n");
            }
        }

        printCity();

        while (pathCheck != 1)
        {
            pathCheck = 0;
            locationCheck = 0;
            memset(input, 0, sizeof(input));
            memset(inputData.departure, 0, sizeof(inputData.departure));
            memset(inputData.arrival, 0, sizeof(inputData.arrival));
            while (locationCheck != 1)
            {
                printf(" - Enter origin location : ");
                fgets(input, sizeof(input), stdin);
                sscanf(input, "%s", inputData.departure);

                locationCheck = cityCheck(inputData.departure);
                if (locationCheck == 0)
                {
                    printf(" * City not found\n");
                }
                else if (locationCheck == -1)
                {
                    printf(" * Enter city only\n");
                }
            }
            printf("\n");
            locationCheck = 0;

            while (locationCheck != 1)
            {
                printf(" - Enter destination location: ");
                fgets(input, sizeof(input), stdin);
                sscanf(input, "%s", inputData.arrival);

                locationCheck = cityCheck(inputData.arrival);
                if (locationCheck == 0)
                {
                    printf(" * City not found\n");
                }
                else if (locationCheck == -1)
                {
                    printf(" * Enter city only\n");
                }
                if (strcmp(inputData.arrival, inputData.departure) == 0)
                {
                    printf(" * Can't enter the same city\n");
                    locationCheck = 0;
                }
            }

            pathCheck = checkReachableFlight(inputData.departure, inputData.arrival);
            if (pathCheck != 1)
            {
                printf(" * Error location are not reachable\n\n");
            }
        }

        printf("\n");
        printf(" * NOTE this program only have the data in one month *\n");
        while (1)
        {
            printf(" - Departure Date [1-30 of the month]: ");
            fgets(input, sizeof(input), stdin);
            sscanf(input, "%d", &inputData.departureDay);

            if ((inputData.departureDay >= 1) && (inputData.departureDay <= 30))
            {
                break;
            }
            else
            {
                printf(" * Enter only [1-30]\n");
            }
        }

        printf("\n");
        printf(" * NOTE The can have up to 100 passengers *\n");
        while (1)
        {
            printf(" - Passengers [1-100]: ");
            fgets(input, sizeof(input), stdin);
            sscanf(input, "%d", &inputData.passenger);

            if ((inputData.passenger >= 1) && (inputData.passenger <= 100))
            {
                break;
            }
            else
            {
                printf(" * Enter only [1-100]\n");
            }
        }

        printf("\n");
        findFlightInPath(inputData.departure, inputData.arrival, inputData.departureDay, inputData.passenger);
    }
}
