//
//  flightFinder.h
//  FinalProject2
//
//  Created by chayaphon bunyakan on 28/4/2563 BE.
//  Copyright © 2563 chayaphon bunyakan. All rights reserved.
//

#ifndef flightFinder_h
#define flightFinder_h

#include <stdio.h>
#include "flightNetwork.h"
#include "flightFinder.h"

void findFlightInPath(char *origin, char *destination, int day, int seat);
void printfAllFlight(FLIGHT_T *pFlight, int pathCount, int travelTime, int seat);
int checkflightInDate(VERTEX_T **pathVertices, int pathCount, int day, int seat);
void selectFlight(FLIGHT_T *pFlight, int pathCount, int intineraryCount, int seat);

#endif /* flightFinder_h */
