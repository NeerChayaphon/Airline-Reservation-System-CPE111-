//
//  updateFlight.h
//  FinalProject2
//
//  Created by chayaphon bunyakan on 30/4/2563 BE.
//  Copyright © 2563 chayaphon bunyakan. All rights reserved.
//

#ifndef updateFlight_h
#define updateFlight_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "flightNetwork.h"

void updateFlight(FLIGHT_T * pFlight,int flightCount,int seat);
void editDataInFile(FLIGHT_T *pFlight,int seatInput);
#endif /* updateFlight_h */
